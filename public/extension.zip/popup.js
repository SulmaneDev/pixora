// =========================================================
// Pixora Sync — popup.js
// Extracts Whisk session token and sends it directly to the
// open Pixora dashboard tab via chrome.scripting.executeScript
// =========================================================

const WHISK_SESSION_URL = 'https://labs.google/fx/api/auth/session';

// Pixora tab URL patterns to look for
const PIXORA_PATTERNS = [
  'localhost',
  '127.0.0.1',
  'vercel.app',
  'pixora'
];

function setStatus(type, message) {
  const dot = document.getElementById('statusDot');
  const text = document.getElementById('statusText');
  const box = document.getElementById('statusBox');

  // Reset
  dot.className = 'status-dot';
  text.className = '';
  box.className = 'status-box';

  if (type === 'loading') {
    dot.classList.add('pulse');
    text.textContent = message;
  } else if (type === 'success') {
    dot.classList.add('green');
    text.classList.add('success');
    text.textContent = message;
    box.classList.add('success');
  } else if (type === 'error') {
    dot.classList.add('red');
    text.classList.add('error');
    text.textContent = message;
    box.classList.add('error');
  } else {
    text.textContent = message; // idle / default
  }
}

function setButton(loading) {
  const btn = document.getElementById('syncBtn');
  const label = document.getElementById('btnLabel');

  if (loading) {
    btn.disabled = true;
    btn.innerHTML = `
      <div class="spinner"></div>
      <span id="btnLabel">Syncing...</span>
    `;
  } else {
    btn.disabled = false;
    btn.innerHTML = `
      <span class="btn-icon">✦</span>
      <span id="btnLabel">Sync to Pixora</span>
    `;
  }
}

async function findPixoraTab() {
  // Get all tabs and find one that matches Pixora patterns
  const allTabs = await chrome.tabs.query({});
  return allTabs.find(tab => {
    const url = (tab.url || '').toLowerCase();
    return PIXORA_PATTERNS.some(pattern => url.includes(pattern));
  });
}

async function extractToken() {
  // First check cache
  const cached = await chrome.storage.local.get(['pixoraToken', 'pixoraTokenTime']);
  const TOKEN_TTL = 45 * 60 * 1000; // 45 minutes

  if (cached.pixoraToken && cached.pixoraTokenTime) {
    const age = Date.now() - cached.pixoraTokenTime;
    if (age < TOKEN_TTL) {
      return cached.pixoraToken;
    }
  }

  // Fetch fresh token from Whisk session
  const tabs = await chrome.tabs.query({ url: 'https://labs.google/*' });
  const whiskTab = tabs.find(t => t.url && t.url.includes('fx'));

  if (!whiskTab) {
    // Open Whisk in background for a fresh session
    await chrome.tabs.create({ url: 'https://labs.google/fx/tools/whisk', active: false });
    // Give it a moment, then retry
    await new Promise(resolve => setTimeout(resolve, 2500));
  }

  const response = await fetch(WHISK_SESSION_URL, { credentials: 'include' });
  if (!response.ok) throw new Error('Not logged in to Whisk. Please visit labs.google and sign in first.');

  const data = await response.json();
  const token = data.access_token || data.accessToken || data.token;
  if (!token) throw new Error('Token not found. Try refreshing the Whisk page and try again.');

  // Cache it
  await chrome.storage.local.set({ pixoraToken: token, pixoraTokenTime: Date.now() });
  return token;
}

async function syncToPixora(token, tab) {
  // Inject a postMessage into the Pixora tab
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: (tok) => {
      window.postMessage({ type: 'PIXORA_TOKEN_SYNCCED', token: tok }, '*');
    },
    args: [token]
  });
}

// === MAIN CLICK HANDLER ===
document.getElementById('syncBtn').addEventListener('click', async () => {
  setButton(true);
  setStatus('loading', 'Finding Pixora dashboard tab...');

  try {
    // 1. Find the Pixora tab
    const pixoraTab = await findPixoraTab();
    if (!pixoraTab) {
      throw new Error('No Pixora tab found. Open your Pixora dashboard first, then try again.');
    }

    setStatus('loading', 'Fetching your Whisk session token...');

    // 2. Extract token
    const token = await extractToken();

    setStatus('loading', 'Sending token to Pixora...');

    // 3. Inject into the Pixora tab
    await syncToPixora(token, pixoraTab);

    // 4. Success!
    setStatus('success', '✦ Synced! Pixora Engine is connected.');
    setButton(false);

    // Briefly highlight the button as success
    const btn = document.getElementById('syncBtn');
    btn.style.background = 'linear-gradient(135deg, #059669 0%, #10b981 100%)';
    btn.style.boxShadow = '0 4px 20px rgba(16, 185, 129, 0.4)';
    btn.innerHTML = `<span style="font-size:16px">✓</span><span>Synced Successfully</span>`;

    setTimeout(() => {
      btn.style.background = '';
      btn.style.boxShadow = '';
      setButton(false);
    }, 3000);

  } catch (error) {
    setStatus('error', error.message || 'Sync failed. Please try again.');
    setButton(false);
  }
});

// On open: check if we have a cached token and show status
(async () => {
  try {
    const cached = await chrome.storage.local.get(['pixoraToken', 'pixoraTokenTime']);
    const TOKEN_TTL = 45 * 60 * 1000;

    if (cached.pixoraToken && cached.pixoraTokenTime) {
      const age = Date.now() - cached.pixoraTokenTime;
      if (age < TOKEN_TTL) {
        const mins = Math.round((TOKEN_TTL - age) / 60000);
        setStatus('success', `Session cached · expires in ~${mins}m. Click to re-sync.`);
        return;
      }
    }
    setStatus('idle', 'Ready to sync your session');
  } catch (e) {
    // Silently ignore
  }
})();
